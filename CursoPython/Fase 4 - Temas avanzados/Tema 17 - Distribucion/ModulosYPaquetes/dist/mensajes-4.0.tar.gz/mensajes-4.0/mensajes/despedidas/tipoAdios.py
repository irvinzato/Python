def despedir():
    print("Nos vemos pronto, con más energía y progreso")

class Despedida:
    def __init__(self):
        print("Hasta luego desde el contructor(__init__) Despedida")