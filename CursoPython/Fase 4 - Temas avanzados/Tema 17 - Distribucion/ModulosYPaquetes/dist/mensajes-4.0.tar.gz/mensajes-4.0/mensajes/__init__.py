#Este archivo se ejecuta automáticamente cuando importamos un paquete, normalmente se define dentro de los paquetes
print("- No es obligatorio tener este archivo dentro de los paquetes pero es una buena práctica !")
print("Cargando el paquete mensajes, soy el papá de los pollitos(saludos y despedidas)")