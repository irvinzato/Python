#ESTE SE UTILIZA PARA IMPORTAR DE MANERA LOCAL NUESTROS ARCHIVOS DE PYTHON(Como /mvn clean package en Java)
#Re utilice lo hecho anteriormente para aprender buenas prácticas y mas maneras de hacer el setup
from setuptools import setup, find_packages

"""V146
Configuración del distribuible(paquete que exportaremos a diferentes proyectos para re utilizar contenido)
Para ejecutar se utiliza en la terminal - "python setup.py sdist" parecido a "mvn clean package"
Despues de que nos génere el archivo "dist/*.tar.gz" hay que ir a su ruta desde la terminal
Y ejecutar "pip install mensajes-1.0.tar.gz"
Posteriormente nos instalara el paquete localmente, con "pip list" podemos ver todos los paquetes instalados de python
Ahora podre utilizarlos en cualquier lugar donde lo importe(Jupyther, terminal, archivos, etc)"""
setup(
    name             = 'mensajes',
    version          = '4.0',
    description      = 'Paquete para saludar y despedir',
    author           = 'Irving Mauricio Silva Rivera',
    author_email     = 'multizato@...',
    url              = 'https.IrvingRivera.com',
    packages         = find_packages(),
    scripts          = [],
    test_suite       = 'tests',   #Para indicar donde tenemos las pruebas(Los diferentes tipos de archivos de testing, necesita el __init__ en el paquete)
    install_requires = [paquete.strip() for paquete in open("requirements.txt").readlines()] #Para los paquetes externos que deba instalar(La mejor forma es hacerlo en otro archivo "requirements.txt")
)                                                                                            #También utiliza el archivo "MANIFEST.in" para incluir el archivo "requirements.txt"
#Para desinstalar la versión anterior y actualizar por la nueva:
#Para actualizar la version se hace el mismo proceso pero al subirla se coloca "pip install mensajes-2.0.tar.gz --upgrade"
#Si no funciona hay que reiniciar el Kernel
#Si queremos eliminar el paquete es con "pip uninstall 'nombrePaquete'"


#También puedo manejar los test y la manera corresta es en la raíz crear la carpeta "tests" con el fichero
#Deberia haber un fichero "test" para cada paquete que estamos utilizando